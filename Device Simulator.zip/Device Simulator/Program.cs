﻿using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

class Program
{
    private readonly static string deviceConnectionString = "HostName=ehn-iotproject.servicebus.windows.net;DeviceId=50f7481b-2a67-4f32-ac65-78e261326031;SharedAccessKeyName=admin;SharedAccessKey=aaA3HRtwi7GpCw6AOqoJcjegXhiRTuy+D+AEhDvsZuI=;TransportType=Mqtt";
    private readonly static string deviceId = "50f7481b-2a67-4f32-ac65-78e261326031"; 

    static async Task Main(string[] args)
    {
        Console.WriteLine("IoT Hub Quickstarts - Simulated device. Ctrl-C to exit.\n");

        using var deviceClient = DeviceClient.CreateFromConnectionString(deviceConnectionString);

        while (true)
        {
          
            var telemetryDataPoint = new
            {
                d = deviceId, // Device ID
                trend = new[]
            {
                new { tag = "Temp", v = 25, t = DateTimeOffset.UtcNow.ToUnixTimeSeconds() },
                new { tag = "Humidity", v = 25, t = DateTimeOffset.UtcNow.ToUnixTimeSeconds() }
            }
            };

          
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint, Formatting.Indented);

            // message object
            var message = new Message(Encoding.UTF8.GetBytes(messageString));

            // Send the message
            try
            {
                await deviceClient.SendEventAsync(message);
                Console.WriteLine($"{DateTime.Now} > Sending message:");
                Console.WriteLine(messageString); // Output the JSON message
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{DateTime.Now} > Exception: {ex.Message}");
            }

            await Task.Delay(1000); // Delay before sending the next message
        }
    }
}